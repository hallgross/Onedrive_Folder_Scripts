HHD — MANUS DROP BUNDLE
=======================
1) EDU_Ebooks_PDFs/  -> 30 ebook PDFs. Upload each as a DIGITAL DOWNLOAD, $15.99, collection "Education Center".
   (EDU_Sales_Listings.md = listing copy; Maker_List.md = catalog.)
2) Juneteenth/HHD_Juneteenth_SCRIPTURE_MASTER_for_Store.csv -> 36 POD designs.
   For each row: open Design_4K_URL (print-ready PNG) -> Printify blank (Product col) -> price from CSV -> collection "Juneteenth".
3) HHD_MANUS_HANDOFF.md -> full step-by-step.
Note: Juneteenth design files are linked by URL in the CSV (open in browser to download the print file).
