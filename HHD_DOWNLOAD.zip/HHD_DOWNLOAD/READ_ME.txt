HHD DOWNLOAD BUNDLE (for Cowork)
================================
EDU_Ebooks_PDFs/        -> 30 written ebook PDFs ($15.99 digital downloads, collection "Education Center")
EDU_Visuals.csv         -> EDU cover-image URLs (open link to download each 2K cover)
HHD_Juneteenth_SCRIPTURE_MASTER_for_Store.csv -> 36 Juneteenth POD designs + 4K print URLs
EDU_Sales_Listings.md   -> elegant listing copy for the EDU ebooks
HHD_MANUS_HANDOFF.md    -> full step-by-step
Note: image files (EDU covers + Juneteenth designs) are linked by URL in the CSVs (open in a browser to download).
